with temp as (select d.productid as pId,p.productname as productN from customer c,[order] o,orderdetail d,product p where c.companyname='Queen Cozinha' and c.id=o.customerid and o.orderdate like '2014-12-25%' and o.id=d.orderid and d.productid=p.id order by p.id)

select 
	group_concat(productN) 
from 
	temp;