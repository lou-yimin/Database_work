with 
	temp as (select distinct shipcountry ,'NorthAmerica' as tplace from [order] where shipcountry in('USA','Mexico','Canada')),
	temp1 as (select distinct shipcountry,'OtherPlace' as tplace1 from [order] where shipcountry not in ('USA','Mexico','Canada') union select * from temp)
select 
	o.id,o.shipcountry,t.tplace1 
from 
	[order] o,temp1 t 
where 
	o.shipcountry=t.shipcountry and o.id>=15445 
order by 
	o.id limit 20;
	